﻿# TODO: Translation updated at 2026-01-14 21:36 

# game/script.rpy:27
translate english start_76b2fe88:

    # nvl clear
    nvl clear

# game/script.rpy:34
translate english start_8146bcbd:

    # "我们沿着海岸走。"
    "We walked along the shore."

# game/script.rpy:36
translate english start_be25f999:

    # "远处有一块巨大的礁石。"
    "In the distance, a massive reef loomed."

# game/script.rpy:38
translate english start_92be95d7:

    # "石头旁有一个漆黑的小点。"
    "Beside the rock was a small, pitch-black speck."

# game/script.rpy:40
translate english start_ba64b40f:

    # nvl clear
    # "西尔维奥又惊又喜。\n\n他已经很久没见过除我以外的人。"
    nvl clear
    "Silvio was astonished and delighted.\nHe hadn't seen anyone but me for a very long time."

# game/script.rpy:44
translate english start_02b8c711:

    # "况且，他已经深深地厌倦了我。\n\n连一口水都不愿分给我喝，\n连一句话都不希求和我讲。"
    "Moreover, he was thoroughly weary of me.\nHe would not share even a sip of water with me, nor did he deign to say a single word to me."

# game/script.rpy:46
translate english start_0a9dac09:

    # nvl clear
    # "他三步并作两步，我紧随其后，\n那具身体就近在眼前了。"
    nvl clear
    "He hurried on, three steps at a time, and I followed close behind; the body was now nearly in view."

# game/script.rpy:52
translate english start_d2a7143d:

    # "阳光晒过的沙子混合着马尿的骚味儿，还有一股难以言喻的气味，\n在不过五米外的距离升腾起来。"
    "Sun-baked sand mixed with the rank odor of horse urine, and an indescribable stench wafted up from barely five meters away."

# game/script.rpy:54
translate english start_1e28367c:

    # "西尔维奥踩到了一只海螺。\n他把鞋子举起来倒掉泥沙，\n而我叹了口气。"
    nvl clear
    "Silvio stepped on a seashell. He lifted his boot and emptied out the sand; I sighed."

# game/script.rpy:56
translate english start_8f8a29a4:

    # nvl clear
    # "死人的面影是模糊的，只有掀起斗篷，\n才看到眼眶附近攀爬的蠕虫。"
    nvl clear
    "The corpse's face was a blurred, indistinct mask; only when the cloak was lifted did I see worms crawling around the eye sockets."

# game/script.rpy:62
translate english start_ed921487:

    # "一张腥烂的、渗出骨骼的脸。\n他已经惨遭摧毁，又被抛尸于此地。"
    "A foul, rotting face with bone exposed. He had been brutally destroyed and his corpse cast aside here."

# game/script.rpy:64
translate english start_b44f58e3:

    # "西尔维奥跪下来，\n一只脚还赤裸着，虔诚地低下了头，\n他未曾对我开口的嘴唇翕动着，\n念完了悼词。"
    nvl clear
    "Silvio knelt down, one foot still bare, bowing his head in piety. His lips — which had never spoken to me — moved as he finished reciting the eulogy."

# game/script.rpy:66
translate english start_902bb1a0:

    # nvl clear
    # "很可惜，在这样的场合，\n我才能见到西尔维奥祷告。"
    "Sadly, only on such an occasion do I get to see Silvio praying."

# game/script.rpy:70
translate english start_ef5d938a:

    # "他很久没有这样做了，也许是因为很久没有吃过面包，也很久没有喝过酒。"
    nvl clear
    "It had been ages since he had done this — perhaps because he had not eaten bread or drunk wine in such a long time."

# game/script.rpy:72
translate english start_c9ff2e91:

    # "我们只记得腐烂的滋味、\n呕吐物的滋味了。"
    "All we remembered now were the tastes of decay and of vomit."

# game/script.rpy:74
translate english start_05d7e6d6:

    # nvl clear
    # "但很幸运，我们看见胡桃树，\n在那么远、但至少可以看见的位置，\n家乡已经向我们露出了帽檐。"
    nvl clear
    "But fortunately, we spotted a walnut tree — distant yet at last visible — and our homeland had already shown us the brim of its rooftops."

# game/script.rpy:78
translate english start_3fa24437:

    # "即使那是被瘟疫和战争余波啃咬后只剩下皮包骨头的生机，\n\n也比荒凉的路途要好得多。"
    "Even if it were little more than skin and bones, gnawed by plague and the aftermath of war, it was still infinitely better than the desolate road."

# game/script.rpy:80
translate english start_db347894:

    # nvl clear
    # "{color=#649BDA}我如同亲兄弟般爱你，\n西尔维奥。"
    nvl clear
    "{color=#649BDA}I love you as if you were my own brother, Silvio.{/color}"

# game/script.rpy:84
translate english start_2e22e3bb:

    # "我走着，向他轻轻地说。"
    "I walked on and softly said to him."

# game/script.rpy:86
translate english start_888ee492:

    # "{color=#649BDA}对我说说话吧。{/color}"
    "{color=#649BDA}Please, speak to me.{/color}"

# game/script.rpy:88
translate english start_3a5012ed:

    # nvl clear
    # "{color=#FF0000}不要自作多情，阿方索。\n\n你只需要和死神说这些话，\n他会好好吻住你的。{/color}"
    nvl clear
    "{color=#FF0000}Don’t be so sentimental, Alfonso. You should save those words for Death; he will give you a proper kiss.{/color}"

# game/script.rpy:92
translate english start_f1c0252e:

    # "西尔维奥这样答道。\n\n他身上那柄破剑随之摇晃着，\n就像一串被风吹过的枯枝。"
    "Silvio answered thus. The battered sword at his side swayed, like a row of dead twigs in the wind."

# game/script.rpy:94
translate english start_76b2fe88_1:

    # nvl clear
    nvl clear

# game/script.rpy:101
translate english start_bb038466:

    # "我和西尔维奥是彼此的敌人。\n我认为他虚伪，他认为我软弱。"
    "Silvio and I were enemies; I saw him as hypocritical, and he saw me as weak."

# game/script.rpy:103
translate english start_2669c1d8:

    # "西尔维奥将自己的每个行为正当化，\n倘若发生在他身上，总能找到点理由，\n\n倘若别人做了一样的事，\n就要遭到他无尽的谴责，\n好像这是他与生俱来的特权。"
    "Silvio justified every one of his actions; if it happened to him, he could always find an excuse. But if someone else did the same thing, he would heap endless condemnation on them, as if it were his birthright."

# game/script.rpy:105
translate english start_1a8c7f61:

    # nvl clear
    # "以他的观点，\n他这辈子没做错过半件事，\n然而他经常道歉，\n开场还要责备自己几句。\n\n{color=#FF0000}无用的仆人！\n\n不称职的骑士！{/color}\n\n……云云。"
    nvl clear
    "In his opinion, he had never done even half a wrong thing in his life, yet he frequently apologized, even opening with a bit of self-reproach. \n\n{color=#FF0000}Useless servant! \nIncompetent knight!{/color}\n\n ...and so on."

# game/script.rpy:109
translate english start_d279d013:

    # nvl clear
    # "结果，经过了巫术一般的过程，\n最终以自己被逼无奈、\n别人罪不容诛结束。\n\n等这些鸡毛蒜皮的小事过了个把月，\n他还要在磨剑的时候假装无意，\n对素不相识的人吹嘘两把。"
    nvl clear
    "In the end, through a process like sorcery, it always ended with him being forced into desperation and everyone else deemed utterly guilty. After those petty squabbles had blown over after a month or so, he would pretend it was all accidental while sharpening his sword and brag about it to complete strangers."

# game/script.rpy:113
translate english start_46494d3c:

    # nvl clear
    # "西尔维奥的指控更加直接：\n\n当他的女儿人头落地，\n我只在一旁看着。"
    nvl clear
    "Silvio's accusation was even more direct:\n\nWhen his daughter's head fell to the ground, I only stood by and watched."

# game/script.rpy:117
translate english start_73628e8a:

    # "我没有拔出佩剑，同那个领主决斗。\n\n也没有高声制止，\n提及一位骑士朋友的荣耀。\n"
    "I did not draw my sword to challenge that lord to a duel. Nor did I loudly intervene by invoking the honor of a knightly friend."

# game/script.rpy:119
translate english start_ee71418e:

    # nvl clear
    # "甚至，我的手指头严丝合缝地嵌拢，\n背在了挺直的腰后，双腿分开，\n如护卫般站直……\n\n有时候，我也会梦见那一刻。"
    nvl clear
    "In fact, my fingers were tightly interlocked behind my straightened back, my legs spread apart, standing like a sentinel… \n\nSometimes I even dream of that very moment."

# game/script.rpy:123
translate english start_bc8a9f3e:

    # "当然指的是西尔维奥之女的血块\n落进粪堆，而眼珠子被赏给了猎犬\n囫囵吞下时。"
    nvl clear
    "Of course, I am referring to the time when the clots of Silvio’s daughter’s blood fell into a dung heap, and her eyeballs were given to the hunting dogs to swallow whole."

# game/script.rpy:125
translate english start_bc7404ba:

    # nvl clear
    # "当时——\n\n我清楚地记得——\n\n我也咽了一下喉咙。"
    "Back then — I remember it clearly — \nI swallowed, too."

# game/script.rpy:129
translate english start_986d48db:

    # "但不是出自食欲，\n\n当然不！"
    "But not out of hunger — of course not!"

# game/script.rpy:131
translate english start_76b2fe88_2:

    # nvl clear
    nvl clear

# game/script.rpy:136
translate english start_0867f2be:

    # "那种感觉和今夜很相似：\n仿佛被猎犬咬穿骨骼的是我，\n被铁钉撕裂皮肤、\n裸露出恶心脏器的是我，\n\n发痒的感觉从内里匍匐爬行出来，\n像一个个魔鬼的精卵，\n控告着我们的罪行。"
    "It felt very much like tonight: as if I were the one whose bones were chewed through by hounds, whose flesh was ripped open by iron spikes, exposing foul organs. The itching sensation crawled up from within, like countless demonic eggs accusing us of our crimes."

# game/script.rpy:138
translate english start_291c2d1f:

    # "西尔维奥早有预感。"
    "Silvio had a premonition."

# game/script.rpy:140
translate english start_8e1b5eea:

    # nvl clear
    # "今天早晨，我们从废弃的畜棚离开，\n吐掉满嘴的干草。\n\n他突然神神叨叨地将我拉至一旁，\n指着小镇中心的枯树说，\n千万不要靠近这棵树。"
    nvl clear
    "That morning we left the abandoned barn, spitting out the dry hay in our mouths. Suddenly, muttering to himself, he pulled me aside and pointed to a withered tree in the center of the town, saying, \n\n{color=#FF0000}Do not approach that tree.{/color}"

# game/script.rpy:146
translate english start_5ce8e2df:

    # "我当时问：{color=#649BDA}为什么？{/color}\n他说：{color=#FF0000}为了不要送掉你这条贱命。{/color}"
    nvl clear
    "At the time I asked, \n{color=#649BDA}Why?{/color} \n\nHe said, \n{color=#FF0000}So you don't lose this \nwretched life of yours.{/color}"

# game/script.rpy:148
translate english start_04c857a2:

    # nvl clear
    # "我试图刨根问底，\n弄清楚是什么东西会要了我的贱命，\n但他闭口不言。\n\n后来的事情证明，\n我这种猜测很愚蠢。"
    nvl clear
    "I tried to press him, to discover what could claim my wretched life, but he said nothing. As it turned out later, my speculation was very foolish."

# game/script.rpy:152
translate english start_76b2fe88_3:

    # nvl clear
    nvl clear

# game/script.rpy:158
translate english start_d7b25f71:

    # "直到夜晚，突入城镇的一道风暴\n击碎了这棵可怜的树木，\n它的枯枝败叶在周边散开，\n激起的灰尘几乎呛住了我的喉咙。"
    "At night, a storm burst into the town and shattered that poor tree. Its dead branches and leaves scattered around, and the dust it raised nearly choked my throat."

# game/script.rpy:164
translate english start_84a1f3cd:

    # "闪电时而照亮景色，\n但大多数时候潜伏于黑暗之中。"
    "Lightning would occasionally illuminate the scene, but most of the time everything lurked in darkness."

# game/script.rpy:166
translate english start_d91953e9:

    # nvl clear
    # "西尔维奥叫我闭紧嘴巴，\n千万不能发出巨大的响声，\n以至于被当成一个活人。\n\n我忽然明白了一切：\n\n如果死神知道这条城镇的生命还没有被彻底摧毁，他定会兢兢业业地回来收拾残局。"
    nvl clear
    "Silvio urged me to keep my mouth shut, not to make the slightest sound, lest I be mistaken for someone alive. \nSuddenly I understood it all:\n\nIf Death discovered that the life of this town had not yet been utterly destroyed, he would surely return diligently to clean up the mess."

# game/script.rpy:170
translate english start_71aa17fa:

    # nvl clear
    # "我听见一条蛇在嘶嘶低喊。"
    nvl clear
    "I heard a snake hissing softly."

# game/script.rpy:174
translate english start_03c46d08:

    # "过了半晌，\n\n才意识到那不是吐信子的声音，\n而是西尔维奥在呼唤我。"
    "After a moment, I realized that sound was not a snake flicking its tongue, but Silvio calling my name."

# game/script.rpy:176
translate english start_f1ca9fd8:

    # "{color=#FF0000}阿方索！在树上！{/color}"
    "{color=#FF0000}Alfonso! Up on the tree!{/color}"

# game/script.rpy:178
translate english start_76b2fe88_4:

    # nvl clear
    nvl clear

# game/script.rpy:183
translate english start_030564ef:

    # "尽管晚了半拍，\n我还是朝自认为的天空猛力挥去。\n\n这不是打击到实物的触感，\n恐怕我又杀了一团空气。\n\n哪怕杀死的是西尔维奥也好啊——\n有一刻，我这样想道。"
    "Though I was half a beat late, I still lunged and struck at the sky. It didn't feel like I hit anything solid; I must have only sliced through air. Even if I had killed Silvio — for a moment I actually thought that."

# game/script.rpy:185
translate english start_d09b8429:

    # nvl clear
    # "{color=#FF0000}阿方索，你这个败类。{/color}"
    nvl clear
    "{color=#FF0000}Alfonso, you scoundrel.{/color}"

# game/script.rpy:189
translate english start_9d0fb31a:

    # "他又在那边咬牙切齿、嘀嘀咕咕。\n\n他什么时候才能意识到，\n他的声音也够大的？"
    "He was gnashing his teeth and muttering. When will he ever realize that his voice is already loud enough?"

# game/script.rpy:191
translate english start_76b2fe88_5:

    # nvl clear
    nvl clear

# game/script.rpy:194
translate english start_491adbc0:

    # "我们在黑暗中\n茫然地运着剑，挥砍空气。\n\n我用剑的方式还算小心，\n但西尔维奥就是草木皆兵了，\n他好似抱着将我和死神\n一并砍死的决心在用劲。"
    "In the darkness we swung our swords aimlessly, hacking at the air. I wielded my sword more cautiously, but Silvio was on edge — he attacked as if determined to chop both me and Death down in one stroke."

# game/script.rpy:196
translate english start_af621012:

    # "有很多在旅途中谋杀盟友的先例，\n我可不想成为其中一个牺牲者。"
    "There are many precedents of traveling companions murdering each other; I didn’t want to become one of those victims."

# game/script.rpy:198
translate english start_00cd9417:

    # nvl clear
    # "但我一口气也不敢呼出来，\n害怕话语被我们不可见、\n不可战胜的力量听见，\n转化为我的弱点。"
    nvl clear
    "But I dared not utter a single breath, fearing that our unseen, invincible force would hear and turn my words into a weapon against me."

# game/script.rpy:202
translate english start_31702c3c:

    # "{color=#FF0000}阿方索！这次不要失手！{/color}"
    "{color=#FF0000}Alfonso! Don’t miss this time!{/color}"

# game/script.rpy:204
translate english start_c875046e:

    # "敌人在哪？"
    "Where is the enemy?"

# game/script.rpy:206
translate english start_1a8ecd2a:

    # nvl clear
    # "上方、下方、前胸、后背？\n他只发出威吓，\n却不告诉我具体的方位。"
    nvl clear
    "Above? Below? Front? Behind? \nHe only uttered threats, yet gave no specific direction."

# game/script.rpy:210
translate english start_91b814ed:

    # "天杀的，他又不是没有剑！\n为什么只满足于当我的指挥官？"
    "Damn it, as if he doesn’t have a sword! Why is he content to remain merely my commander?"

# game/script.rpy:215
translate english start_34673ec6:

    # "这一刻我起了无名火，\n朝身后竭尽全力劈砍过去，\n就像与人决斗时那样使劲。"
    nvl clear
    "In that moment a nameless rage welled up in me, and I swung backward with all my strength, just as if I were in a duel."

# game/script.rpy:217
translate english start_90408092:

    # nvl clear
    # "成功了！\n\n我定是伤到了他，\n这一次，我感觉确确实实划开了\n一种柔软而有韧性的东西。\n\n我切开了它，\n我对某种实体造成了伤害，\n我的敌人大难当头了！"
    nvl clear
    "Success!\n\nI must have struck him; this time I truly felt I had sliced through something soft yet resilient.\n\nI had cut it open, I had hurt some tangible thing — my enemy was in grave trouble!"

# game/script.rpy:221
translate english start_76b2fe88_6:

    # nvl clear
    nvl clear

# game/script.rpy:226
translate english start_99ac964c:

    # "我又一次出击，\n希望不要只是伤到他的皮毛，\n导致他趁机抱头鼠窜，\n将来某天又要回来报仇。"
    "I launched another attack, hoping I had not merely grazed him — I didn’t want him to flee in panic and return someday for revenge."

# game/script.rpy:231
translate english start_21d5fdb6:

    # "我听见一声吃痛的叹息——\n\n今天必是我的良辰吉日，\n因为我几乎未曾失手！"
    "I heard a pained groan —\n\nToday must be my lucky day, for I had scarcely missed even once!"

# game/script.rpy:233
translate english start_f347f564:

    # nvl clear
    # "可是为什么我成功了，\n西尔维奥却一句话都不再说？"
    nvl clear
    "But why, \n\nthough I had succeeded, \n\ndid Silvio not utter a single word?"

# game/script.rpy:237
translate english start_b09885a0:

    # "这一刻，理智短暂地回到了我的头脑，\n\n我突然又一次醒悟，\n感慨起自己的愚蠢：\n\n如果那是死神，\n我怎能用剑伤害到他呢？"
    nvl clear
    "In that instant, reason briefly returned to me.\n\nI suddenly realized my own foolishness:\n\nIf that had been Death, how could I have hurt him with my sword?"

# game/script.rpy:239
translate english start_76b2fe88_7:

    # nvl clear
    nvl clear

# game/script.rpy:244
translate english start_ffe0c634:

    # "想来我砍伤的是西尔维奥，\n\n我唯一的盟友，\n\n长途旅行的拍档，\n\n相看两厌的老朋友，\n\n曾分享过数十年命运苦果的人啊！"
    "Then I realized it was Silvio I had wounded,\nmy only ally,\nmy partner on this long journey,\nour long-suffering old friend —\nthe man who had shared with me the bitter fruits of fate for decades!"

# game/script.rpy:246
translate english start_ddfa0712:

    # nvl clear
    # "{color=#649BDA}西尔维奥！\n你在哪？\n\n别犯糊涂了！\n我们根本不该留在这儿！{/color}"
    nvl clear
    "{color=#649BDA}Silvio! Where are you?\nDon’t lose your mind! We should never have stayed here!{/color}"

# game/script.rpy:250
translate english start_08209d7b:

    # "我忍不住大喊大叫，\n只要他回我一句臭骂，\n或者，哪怕是听到\n他再痛苦地呻吟一声！"
    "I couldn't help shouting; just to hear him curse back at me, or even to hear one more pained groan from him!"

# game/script.rpy:252
translate english start_4b2638bc:

    # nvl clear
    # "我就立刻抓起他的领子，\n朝遥远的黑夜里疯狂奔逃。\n\n撞到墙壁也好，\n被尖锐的树枝扎到头破血流也罢，\n\n只要不留在这里，\n继续令人困惑的战斗，\n总要好得多！"
    nvl clear
    "I could have grabbed his collar and run madly into the distant night.\n\nEven if I crashed into walls or had my head split open by sharp branches, as long as we were not stuck here continuing this maddening fight, it would be so much better!"

# game/script.rpy:256
translate english start_86fda88a:

    # nvl clear
    # "可是他没有回答我，\n直到我的心在胸膛里跳了一下，\n他一声不吭。\n\n心跳了两下，\n他也下定决心不搭理我。\n\n三下，我猜想\n西尔维奥已经和我绝交了。"
    nvl clear
    "But he gave me no answer, not even when my heart skipped a beat.\nAfter two beats, it was clear he had decided not to respond to me.\nOn the third, I figured Silvio had already cut ties with me."

# game/script.rpy:262
translate english start_b6dca116:

    # nvl clear
    # "数年的情谊早已寡淡如水，\n就算他忍住没有提前杀死我，\n此刻我的忘恩负义，\n也应该得到原谅了。"
    nvl clear
    "Years of friendship had long since grown as shallow as water; even if he had managed not to kill me earlier, at this point my ingratitude should be forgiven."

# game/script.rpy:266
translate english start_9c7a2048:

    # "我毫不犹豫地独自狂奔出去，\n一边用剑徒劳地挥舞，\n打算砍碎一切阻拦我的东西。\n我注意着脚下，可不能在这个时候，\n被一颗渺小的石子夺取了去路！"
    nvl clear
    "I ran out madly without hesitation, swinging my sword in vain, ready to chop through anything in my way. I watched my footing — this was not the time for a tiny pebble to trip me up!"

# game/script.rpy:268
translate english start_76b2fe88_8:

    # nvl clear
    nvl clear

# game/script.rpy:272
translate english start_f8c523f7:

    # "我向前狂奔！您能想象吗？\n\n当一个人拼尽全力要逃命，哪怕他的鞋子被磨破，脚后跟擦掉了皮，不断渗出殷红的血滴，一块脚指甲壳被荆棘剥开，皮肤扎出细密的漏洞，喉咙被风攥紧，浑身上下没有一处不是难受的，\n\n他也能忍受。"
    "I ran headlong forward! Can you imagine?\n\nWhen a man is fighting for his life with all his strength, even if his shoes wear through, his heels are rubbed raw and bleeding, a toenail is torn off by thorns, his skin is punctured by countless tiny holes, his throat constricted by the wind — with every part of his body in agony — he can endure it all."

# game/script.rpy:274
translate english start_1e0b314c:

    # nvl clear
    # "最不堪回想的是，即使在这样一个可怕的时刻，我也在想西尔维奥。\n\n我想的是：如果因为西尔维奥对风暴的预言而死，那就成全了他的胜负欲，可我迫切需要换一个死因。\n\n我必须从他的预言中逃脱出去，我必须战胜西尔维奥的诅咒。"
    nvl clear
    "What is hardest to recall is that even at such a terrifying moment, I was thinking of Silvio.\n\nI was thinking: if I die because of Silvio's prophecy about the storm, that would only satisfy his thirst for victory, but I desperately needed a different cause of death."

# game/script.rpy:278
translate english start_1fa7cd0e:

    # nvl clear
    nvl clear

# game/script.rpy:282
translate english start_76b2fe88_9:

    # nvl clear
    "I must escape his prophecy, \n\nI must break Silvio's curse."

# game/script.rpy:287
translate english start_a9ddf12d:

    # "我痛苦地喊叫一声，额头撞在硬邦邦的木板上，于是我将它砍碎。"
    nvl clear
    "I cried out in pain, my forehead striking the hard wooden board — so I chopped it to splinters."

# game/script.rpy:292
translate english start_14b9eda0:

    # "显然，这不是一个明智的决定，这一剑连带着消灭了可供支撑的物体，还有一些木屑肯定是掉进了眼眶。\n\n我流着泪，捂着额头，连忙摸进了旁边的屋子——原来砍碎的木头附近，不到半米的距离，就是敞开的大门。"
    "Clearly, that was not a wise decision; that slash destroyed the supporting structure, and some wood splinters surely got into my eyes."

# game/script.rpy:294
translate english start_e5da824d:

    # nvl clear
    # "一个受伤的人，栽倒在干草堆里。\n就像疲惫的士兵在战友的尸体旁沉沉睡着一样，我从来不挑剔入睡的环境。"
    nvl clear
    "Tears streaming as I clutched my forehead, I quickly stumbled into the adjacent room — it turned out that less than half a meter from the wood I had shattered was an open door."
    "An injured man, collapsed in a pile of hay. Like a weary soldier sleeping heavily beside his comrade's corpse, I never was picky about my sleeping conditions."

# game/script.rpy:301
translate english start_5dd04684:

    # "但惊雷响起，几乎震聋了我的耳朵。\n\n为什么雷声这么近？我不是一路狂奔，远离了风暴的中心吗？"
    nvl clear
    "But thunder roared, nearly deafening me.\n\nWhy was it so close? Hadn't I been running as fast as I could, away from the center of the storm?"

# game/script.rpy:303
translate english start_76b2fe88_10:

    # nvl clear
    nvl clear

# game/script.rpy:309
translate english start_8e6d66f7:

    # "就像在安抚我一样，有双柔嫩的、想必属于女人的手，轻轻贴在我的手背上。\n\n我仔细掂量、比较了一下，比我曾经的妻子的手更柔嫩，因为她常年在锅炉前练习冶铁，双手像铁桶表面一样粗糙。"
    "As if to soothe me, a pair of soft, definitely feminine hands gently pressed upon the back of my hand.\n\nI felt them carefully, comparing them with my late wife's hands — these were even softer, since my wife had spent years at the forge and her hands were as rough as iron buckets."

# game/script.rpy:311
translate english start_35273b20:

    # "我懒得再想这女人是死是活了，只急切地伸出双手，贪婪地拥她入怀，十根指头向上探，期待抓住她柔嫩的奶子。"
    nvl clear
    "I didn’t even bother to wonder if this woman was alive or dead; eagerly I reached out both hands and greedily pulled her into my embrace, all ten fingers reaching up, longing to grasp her tender breasts."

# game/script.rpy:313
translate english start_8c7a1586:

    # nvl clear
    # "但这具身体轻轻颤抖了一下，便不着痕迹地同我拉开距离，像在逗弄我似的，反而令我感到一种愉悦。\n\n我的心情得到了缓解，\n\n便渐渐睁开眼睛。"
    nvl clear
    "But the body trembled slightly and then drifted away from me imperceptibly, as if teasing me — and instead I felt a strange delight.\n\nMy tension eased,\n\nand I slowly opened my eyes."

# game/script.rpy:317
translate english start_76b2fe88_11:

    # nvl clear
    nvl clear

# game/script.rpy:322
translate english start_7627bc5c:

    # "{color=#AF4DFF}……从今往后，{/color}"
    "{color=#AF4DFF}…From now on,{/color}"

# game/script.rpy:324
translate english start_72451d4d:

    # "{color=#AF4DFF}您就是杀伐果断的活兔将军，{/color}"
    "{color=#AF4DFF}you shall be the General Hare,{/color}"

# game/script.rpy:326
translate english start_f44b4538:

    # "{color=#AF4DFF}而我是您美艳照人的双头公主。{/color}"
    "{color=#AF4DFF}and I will be your Princess Duocephala.{/color}"

# game/script.rpy:328
translate english start_346755e6:

    # nvl clear
    # "闪电照亮景色。我看见漏风的墙壁透出不远处的枯树，看见风暴积蓄着它毁灭性的力量，看见一双柔美、白皙的手，欲拒还迎地挂在面前的空气中，似乎要搭在我身上，却犹豫不决。\n\n她的身体被斗篷包裹着，遮蔽了我想要看见的曲线。我的眼泪从枯竭的眼角不断流下，冲洗着肮脏的面颊。"
    nvl clear
    "Lightning illuminated the scene. Through a drafty wall I saw a withered tree not far away, saw the storm gathering its destructive power; I saw a pair of tender, pale hands hanging before me in mid-air, as if they wanted to embrace me but hesitated."

# game/script.rpy:332
translate english start_22e8aac3:

    # nvl clear
    # "我咽了一下喉咙，但不是出于欲望，\n也不是出于食欲。"
    nvl clear
    "Her body was wrapped in a cloak, hiding the curves I longed to see. Tears streamed down from my parched eyes, washing over my filthy cheeks."
    "I swallowed, but not out of desire, nor out of hunger."

# game/script.rpy:338
translate english start_1613fd44:

    # "我直勾勾地瞧着她纤细脖颈上悬挂着两个肿瘤似的头颅。\n\n其中一个不愿面对我，另一个则低垂着眼睛，虽没有直视我，却审判着我。"
    nvl clear
    "I stared intently at the two tumor-like heads hanging from her slender neck.\n\nOne refused to face me, the other looked down — though neither met my gaze, both seemed to judge me."

# game/script.rpy:340
translate english start_92dba39e:

    # nvl clear
    # "棕红色、蜷曲的短发，粗糙黝黑的脸，相比于同龄人更加硕大的鼻子，即便\n死去也皱紧的眉头，切掉一半的左耳。"
    nvl clear
    "Chestnut-colored, curly short hair; a rough, dark complexion; a nose larger than that of her peers; even in death her brow was furrowed; half of her left ear had been severed."

# game/script.rpy:346
translate english start_08ae8169:

    # "毫无疑问，那确确实实是\n西尔维奥的头颅。"
    "Without a doubt, it was indeed Silvio’s skull."

# game/script.rpy:348
translate english start_a855305f:

    # "我曾在风暴中心伤害了西尔维奥、\n背离了西尔维奥，\n却又重新回到了他的身边。"
    nvl clear
    "I had wounded Silvio in the heart of the storm, had betrayed Silvio, yet I had returned again to his side."

# game/script.rpy:350
translate english start_2ee497e8:

    # nvl clear
    # "{color=#AF4DFF}您允许吗？{/color}\n\n她的双手环绕住我的脖子，\n近乎深情地说。"
    nvl clear
    "{color=#AF4DFF}Do I have your permission?{/color}\n\nHer arms wrapped around my neck as she said it, her voice almost tender."

# game/script.rpy:354
translate english start_1c23e834:

    # "我流下一滴干涸的泪，\n一句话也不肯说。"
    "A single, dry tear ran down my face; I refused to utter a word."

# game/script.rpy:356
translate english start_b9bb1f60:

    # nvl clear
    # "她倾身向前，\n以西尔维奥的嘴唇亲吻了我。"
    nvl clear
    "She leaned forward and kissed me with Silvio’s lips."

# game/script.rpy:362
translate english start_88955578:

    # "有一滴不属于我的眼泪落在手背上。"
    "A tear not my own fell onto the back of my hand."

# game/script.rpy:364
translate english start_76b2fe88_12:

    # nvl clear
    nvl clear

# game/script.rpy:373
translate english start_9d783b92:

    # "在黑暗中，我回想起……\n第一次吮吸母乳。"
    "In the darkness, I remembered...\nthe first time I drank my mother’s milk."

# game/script.rpy:375
translate english start_3fca5e09:

    # "人们常说这段记忆是胡扯，可我总坚信自己记得，甚至——现在不怕说了——比信仰更虔诚。我记得，母亲的脐带连着我的眼睛，从出生前，我就看厌了这个世界，于是退缩，想要回去，但又因为扯不断脐带而放弃。"
    nvl clear
    "People often say that memory is nonsense, but I’ve always believed I remember it — even now I’m not afraid to say it — more devoutly than faith. I remember my mother’s umbilical cord attached to my eyes; even before I was born I had already grown tired of this world, and I recoiled, wanting to return, but gave up because I couldn’t sever the cord."

# game/script.rpy:377
translate english start_a4556a6a:

    # nvl clear
    # "于是，我第一次从人的体内放出血，带出黏连的细肉和挤压的粪便。\n\n首次犯罪太过轻巧，一个产妇、一个接生婆，就为我完成了所有的解释，甚至用不上一把剑，或者一段誓言。"
    nvl clear
    "And so, for the first time I bled from a human body, bringing forth sticky flesh and compacted excrement.\n\nThat first crime was far too simple — one midwife, one obstetrician gave me all the explanation I needed, without even using a sword or an oath."

# game/script.rpy:381
translate english start_76b2fe88_13:

    # nvl clear
    nvl clear

# game/script.rpy:386
translate english start_4e45d542:

    # "我合上眼睛，扶着畜棚的干草，把嘴巴里不断产生的酸液吐出来，猛烈咳嗽，用头撞地板。\n\n曾经有人因为头疼而死吗？我相信肯定有过这类事。\n\n那么，有人因为女人的吻而死吗？压根不用多说，这种事肯定更为常见。"
    "I closed my eyes, braced against the barn’s hay, and vomited the sour bile in my mouth, coughing violently and banging my head against the floor."
    nvl clear
    "Has anyone ever died of a headache? I’m sure that’s happened.\n\nThen, has anyone ever died from a woman’s kiss? Needless to say, that must be even more common."

# game/script.rpy:388
translate english start_b5ede630:

    # nvl clear
    # "西尔维奥的预言是一个半真半假的谎言，真实在于此地当真存在一个魔鬼，虚假在于他连自身都难保。"
    nvl clear
    "Silvio’s prophecy was a half-true lie: the truth was that a demon truly existed here; the falsehood was that he himself couldn’t save himself."

# game/script.rpy:392
translate english start_bb4ac6b3:

    # "况且，死神明显不是我们曾经在食人者洞窟的壁画里看到的那样，由化为骸骨的男性所担任，而是垂泪、哀怜却不以正面示人的美女。"
    "Moreover, Death was clearly not like the skeletal male depicted in the cannibal’s cave paintings, but rather a tearful, sorrowful beauty who never showed her face directly."

# game/script.rpy:394
translate english start_1e986dd7:

    # nvl clear
    # "如今，西尔维奥反而成了\n死神的扮演者之一。"
    nvl clear
    "Now, on the contrary, Silvio had become one of Death’s actors."

# game/script.rpy:398
translate english start_e2338253:

    # "不知道现在，他的灵智飘荡在什么地方呢？能遇见他那惨遭处刑的女儿吗？\n\n我在四十余年的岁月里曾经砍下不少罪犯的脖子，倘若我死了，也不会去往高尚者的巢穴，兴许还能再和西尔维奥大吵一架、随后郁郁不乐地分道扬镳呢。"
    "I wonder now where his spirit wanders. Has it met his daughter who was so brutally executed?"
    nvl clear
    "In over forty years I have beheaded many criminals; if I were to die, I wouldn’t be going to any noble afterlife. Perhaps I could even have one last argument with Silvio, then sorrowfully part ways."

# game/script.rpy:400
translate english start_0698dc66:

    # nvl clear
    # "光是化解头疼，就花了我不少时间。\n\n我回忆了祖辈讲述过的一系列故事，\n背诵了来源未必可靠的族谱，\n又一次感到双脚站在处刑场的泥地上，\n再一次闻到了那个年轻女孩的血浆。\n\n有时，头疼因此而缓解，但过了一会，痛感只是从脑袋左侧转移到右侧。"
    nvl clear
    "Just to relieve the headache took quite some time.I recalled the series of stories told by my ancestors,recited some dubious genealogies,felt once again my feet on the muddy ground of an execution site,and smelled once again that young girl’s blood."
    nvl clear
    "Sometimes that eased the headache, but after a while the pain just moved from the left side of my head to the right."

# game/script.rpy:404
translate english start_94acb769:

    # nvl clear
    # "我尝试放空自己，调整呼吸，渴望进入另一个没有过去亦没有未来的世界，\n自我挤压成比灰尘更小的微粒的世界，\n但却沮丧地发现自己做不到，\n这对头脑的疼痛更是于事无补。"
    nvl clear
    "I tried to empty my mind, steady my breath, longing to enter another world without past or future — to compress myself into particles smaller than dust — but frustratingly I found I could not, and it did nothing to ease the pain in my head."

# game/script.rpy:408
translate english start_32bb8d9a:

    # "最后我睡着了，再次醒来时，发现多数头发都浸泡在呕吐物里，浓烈的气味\n催使我又吐了一次。"
    nvl clear
    "Finally I fell asleep, and when I woke again I found most of my hair soaked in vomit; the strong stench made me vomit once more."

# game/script.rpy:410
translate english start_e8c69a82:

    # nvl clear
    # "我随便捡起几束干草，擦了擦头发，\n抹了抹嘴，用肮脏的指甲壳抠掉眼屎，\n才发现熹微的光束出现在墙壁裂口。\n\n风暴已经停息了。"
    nvl clear
    "I hastily grabbed a few handfuls of dry hay, wiped my hair, wiped my mouth, and scratched at the gunk in my eyes with dirty nails — then I noticed a faint beam of light appearing through a crack in the wall.\n\nThe storm had finally passed."

# game/script.rpy:414
translate english start_bd3b3ee6:

    # "{color=#649BDA}公主！……您在哪儿？{/color}"
    nvl clear
    "{color=#649BDA}Princess! …Where are you?{/color}"

# game/script.rpy:416
translate english start_c3ddc37c:

    # "我出声喊道，才发现自己的声音像感冒似的，又像含了一口痰。"
    "I called out, only to discover that my voice sounded like I had a cold, or as if it were full of phlegm."

# game/script.rpy:418
translate english start_105e9b42:

    # nvl clear
    # "我吐掉刚才那句话，\n支起身子，寻找我的剑。\n\n但剑不在这里，公主也不在这里。\n我为什么会想要找到她呢？\n为什么要喊她公主，而不是魔鬼呢？\n\n这是一个不着调的主意，引得我沙哑地笑了几声。最后我走出门去。"
    nvl clear
    "I spat out the words I had just said and sat up, looking for my sword.\n\nBut the sword was not here, nor was the princess. Why had I even wanted to find her? Why had I called her princess instead of devil?"
    nvl clear
    "It was an absurd idea, and I laughed hoarsely to myself. \n\nFinally, I walked outside."

# game/script.rpy:422
translate english start_76b2fe88_14:

    # nvl clear
    nvl clear

# game/script.rpy:427
translate english start_60604e3c:

    # "明亮、柔和、嘈杂、散发着食物香气的早晨的村镇，铺展在我眼前。"
    "The village in the morning was bright, gentle, noisy, filled with the scent of food — it unfolded before my eyes."

# game/script.rpy:429
translate english start_8db622e3:

    # "昨日被死神清洗的城镇，\n完全翻了模样。\n\n那棵枯树散发着惹人生厌的生机，\n树杈上站着一只渡鸦，\n它似乎在打量我，眼珠打着转，\n又忽然朝远方飞去。"
    nvl clear
    "The town that Death had cleansed just yesterday had been completely transformed.\n\nThe withered tree now exuded a strangely repulsive vitality. On its branch perched a crow, as if sizing me up, its eyes rolling — then it suddenly flew off into the distance."

# game/script.rpy:431
translate english start_de1ca7f4:

    # nvl clear
    # "地面上有鞋印、泥泞、马粪和店铺\n泼出来的混着肉腥味的脏水。\n\n西尔维奥不在这里。\n\n公主也不在这里。\n\n我的剑也不在这里。\n\n没有人在试图把一柄剑扔进冶炼炉。"
    nvl clear
    "The ground was covered with footprints, mud, horse manure, and foul-smelling waste water spilled from the shops."
    nvl clear
    "Silvio was not here.\n\nThe princess was not here.\n\nMy sword was not here.\n\nNo one was attempting to throw a sword into a smelting furnace."

# game/script.rpy:435
translate english start_76b2fe88_15:

    # nvl clear
    nvl clear

# game/script.rpy:438
translate english start_d9622896:

    # "{color=#AF4DFF}您觉得我足够美丽吗？{/color}"
    "{color=#AF4DFF}Do you think I am beautiful enough?{/color}"

# game/script.rpy:440
translate english start_a5503f3d:

    # "她的声音从天穹传来。我连忙抬起脸，向前挪动几步，恰好让她庞大头颅\n垂下的阴影将我全身覆盖。"
    "Her voice came from above. I quickly raised my face and took a few steps forward, just in time for the shadow of her enormous hanging head to cover me completely."

# game/script.rpy:442
translate english start_172e58f3:

    # "美艳照人的双头公主有着宽阔的身体，如同一座岛屿般威严。"
    "The dazzling two-headed princess had a broad form, as majestic as an island."

# game/script.rpy:444
translate english start_b6f3acf5:

    # nvl clear
    # "她恋恋不舍地收回视线——\n刚才，她注视着远方，\n根据我昨天来时的地形，\n那恐怕是海岸边，\n远航船停泊的角落——\n再看向我。\n\n她柔美的睫毛像细密的月亮，\n高高悬挂在山谷之间。"
    nvl clear
    "She reluctantly withdrew her gaze— just moments ago she had been staring into the distance, likely at the shoreline where ships were moored, based on the landscape from yesterday— then she looked back at me.\n\nHer soft eyelashes were like a delicate sliver of moon, hanging high between the valley peaks."

# game/script.rpy:448
translate english start_0d0097e4:

    # nvl clear
    # "{color=#649BDA}……要是你不美，\n这世上就没有美人了。{/color}"
    nvl clear
    "{color=#649BDA}…If you were not beautiful, there would be no beauty left in this world.{/color}"

# game/script.rpy:452
translate english start_1111ec3e:

    # "我哽咽了一下，又立刻说道。"
    "I choked on a sob, then immediately continued speaking."

# game/script.rpy:454
translate english start_7074fe07:

    # "{color=#649BDA}你想从我这里得到什么？\n只要是我能办到的，我都会尽力而为。{/color}"
    "{color=#649BDA}What do you want from me? As long as it’s within my power, I will do my utmost to grant it.{/color}"

# game/script.rpy:456
translate english start_4516b1fc:

    # nvl clear
    # "我停顿的间隙很小。\n\n因为我总奇怪地认为，如果表现出明显的犹豫，就会激起她的悲伤。\n\n但我不想被一颗从天而降的巨大泪滴\n杀死，也不想被浇灌成琥珀里的牛虻。"
    nvl clear
    "I hardly paused.\n\nFor I oddly believed that any hesitation on my part would sadden her.\n\nBut I did not want to be killed by a giant teardrop falling from the sky, nor turned into a botfly preserved in amber."

# game/script.rpy:460
translate english start_5ee3a61f:

    # nvl clear
    # "{color=#AF4DFF}我要您替我办一件事。\n恰好有那么一件事，\n我想交由您的手去做。{/color}"
    nvl clear
    "{color=#AF4DFF}I have a task for you.\nThere happens to be something I wish to entrust to your hands.{/color}"

# game/script.rpy:464
translate english start_34e7b20c:

    # "她轻轻地笑了，美丽的双目眯起来。"
    "She smiled softly, her beautiful eyes narrowing."

# game/script.rpy:466
translate english start_0deef366:

    # "我注意到一根手指头搭在屋棚顶端，\n既没有毛发，也没有指甲壳。"
    "I noticed a finger resting on the rooftop of the shed — it had neither hair nor a nail."

# game/script.rpy:468
translate english start_1f22c586:

    # nvl clear
    # "只要她弹指一挥，我的脑袋就会从肩上脱落，那时，她想成为三头公主，还是其它姿态的魔鬼，都任凭她的意思。"
    nvl clear
    "With a flick of her finger my head would fall from my shoulders; then whether she wanted to be a three-headed princess or some other form of demon would be entirely up to her."

# game/script.rpy:472
translate english start_19183642:

    # "我不禁开始好奇，\n西尔维奥的头颅也变得如此硕大吗？\n\n迎着日落的方向，我的确看见他那\n硕大的鼻子在公主背面露出阴影，\n就像是一轮刻薄的月亮。"
    nvl clear
    "I couldn’t help wondering:\nhad Silvio’s skull become this enormous too?\n\nFacing the sunset, I indeed saw his massive nose casting a shadow over the princess’s back — like a scornful moon."

# game/script.rpy:474
translate english start_aa711f68:

    # nvl clear
    # "{color=#AF4DFF}您瞧，我的城镇里一应俱全。几乎所有需要的东西，都已经摆设齐全了。\n\n无论是嗜血的杀人魔，还是耐心的厨师，无论是接待游民的教士，还是忠实的清道夫。小到一座接应骑士和信使的辉煌厅堂，大到卧室里的抽屉柜子……\n\n我还有什么可供奢望呢？\n我难道还能变得更贪婪吗？{/color}"
    nvl clear
    "{color=#AF4DFF}You see, my town has everything one could need. Almost all necessities have been provided.\n\nFrom bloodthirsty murderers to patient cooks, from priests who welcome wanderers to loyal scavengers. From the grandest hall for knights and messengers to the most humble dresser in a bedroom…{/color}"
    nvl clear
    "{color=#AF4DFF}What more could I possibly desire? \n\nCould I become any more greedy?{/color}"

# game/script.rpy:478
translate english start_9f426171:

    # nvl clear
    # "{color=#AF4DFF}我已经有了一颗宽敞的心，有了两颗美丽的头颅。从前，我总遗憾自己的相貌单调乏味，如今连这烦恼都遁入黑夜，消失不见。为什么生活如此美好，没有丝毫烦恼呢？为什么一切都如愿以偿，万事万物总要眷顾、宠爱我呢？\n\n啊！多么希望，这样的日子化为永恒！如果世界永不散场，观众永不离席，\n那可就太好了！{/color}"
    nvl clear
    "{color=#AF4DFF}I already have an ample heart and two beautiful heads. In the past I lamented that my appearance was plain, but now even that worry has vanished into the night.{/color}"
    nvl clear
    "{color=#AF4DFF}Why is life so wonderful, without a speck of trouble? Why does everything always go my way, as if all things favor and cherish me?\n\nAh! How I wish these days could last forever! If the world never ended and the audience never left their seats,\nthat would be perfect!{/color}"

# game/script.rpy:482
translate english start_f01681db:

    # nvl clear
    # "{color=#AF4DFF}我希望跨越海洋的所有陆地，要让\n所有骑士、处刑人，还有垂泪的女儿，\n都来光顾、都来欣赏我完美的宫殿。\n这样的想法，恐怕算不上贪婪吧？\n追随自己的欲望，难道会有任何\n值得指摘的差错吗？\n\n啊！这再自然不过！我的心多么华丽，我的言行多么准确一致，我的信念从未有过差错，正是因此你才追随了我！{/color}"
    nvl clear
    "{color=#AF4DFF}I wish that across every land beyond the sea, all knights, executioners, and even mourning daughters would come to behold my perfect palace.Is such a desire truly greed? To follow one’s desire — is there any mistake in that?{/color}"
    nvl clear
    "{color=#AF4DFF}Ah! It’s only natural! My heart is so magnificent, my words and deeds so perfectly consistent; my faith has never been wrong, and it is precisely for this reason that you followed me!{/color}"

# game/script.rpy:486
translate english start_b73a634c:

    # nvl clear
    # "她忽然说出这一番话，声调上扬，\n句尾在广阔的天空中嗡嗡作响。\n\n她的声音的确有掀起风暴的能力，\n连她落入沉默时垂下的双眼，\n都叫我心神不宁。"
    nvl clear
    "She suddenly spoke these words, her tone rising, the final syllables buzzing through the vast sky.\n\nHer voice indeed had the power to raise a storm; even as she fell silent and let her eyes droop, it left me uneasy."

# game/script.rpy:490
translate english start_0b5e1f07:

    # "{color=#649BDA}公主！……啊，您说得完全正确。{/color}"
    "{color=#649BDA}Princess! …Ah, you are absolutely right.{/color}"

# game/script.rpy:492
translate english start_656d8dac:

    # nvl clear
    # "我做出一副附和的样子，由于恐惧\n而绷紧神经，却忽视了两道泪痕\n从眼下划过、显得狼狈丑陋的事实。"
    nvl clear
    "I nodded in agreement, nerves taut with fear, but I ignored the fact that two tear tracks had slid down under my eyes, making me look disheveled and ugly."

# game/script.rpy:496
translate english start_bd21269e:

    # "然而，昨夜赐予我一个吻的美女，\n宽容地大笑起来。"
    "However, the beauty who had granted me a kiss last night laughed indulgently."

# game/script.rpy:498
translate english start_92246894:

    # "{color=#AF4DFF}那么，您就到我的怀里来吧！{/color}"
    nvl clear
    "{color=#AF4DFF}Then, come into my arms!{/color}"

# game/script.rpy:500
translate english start_76b2fe88_16:

    # nvl clear
    nvl clear

# game/script.rpy:505
translate english start_d39217b8:

    # "美艳照人的双头公主微微倾斜着面庞，垂下睫毛。这时我才看清她金色外衣\n如同贝类肉体材质的绣线，随着两根\n无甲手指的轻巧动作崩裂散开，发出\n金属交击似的响亮振动。"
    "The enchanting two-headed princess tilted her face slightly, lowering her lashes. Only then did I see her golden robe, embroidered with threads resembling fleshy shells; with the deft movement of her two fingernail-less fingers, the threads tore apart with a loud clang like colliding metal."

# game/script.rpy:507
translate english start_c03c9c6f:

    # "这景象令我登时着了迷，深深地\n吸入一口捎带着铁锈味的空气。"
    nvl clear
    "The sight immediately mesmerized me, and I drew in a deep breath of air tinged with the smell of rust."

# game/script.rpy:509
translate english start_b7ac9244:

    # nvl clear
    # "双头公主解开了华美的外衣，袒露出\n胸膛巨大的空洞。\n\n我别无选择，也无暇顾及在这时痉挛的肠胃，便在她投下的阴影里挪动起来，\n\n攥紧交叠成团、淌着粘腻汁液的肠子，以一种最体面的姿态向上攀登。"
    nvl clear
    "The two-headed princess unclasped her splendid cloak, exposing the enormous hollow of her chest. I had no choice, nor time to heed my churning stomach, so I began to move in the shadow she cast, clutching the coiled intestines, dripping with viscous fluid, and climbed upward with as much dignity as I could muster."

# game/script.rpy:513
translate english start_611fd506:

    # nvl clear
    # "城镇的居民们虽被我不断窥视，却似乎看不见我。在攀爬的过程中，我屡次\n撞到在街上疯玩的孩童，还打翻了一个\n跛脚的老妇人，但他们都不曾咒骂我。\n\n有时，他们露出疲惫无力的神情，有时则对空气发怒，用脚踢打地砖。但他们的责怪弥散在整个自身不可控的世界，从未真正注意到罪魁祸首。"
    nvl clear
    "Although I kept watching the townspeople, it was as if they could not see me. As I climbed, I repeatedly bumped into children crazily playing in the street and even knocked over a limping old woman, yet none of them cursed me."
    nvl clear
    "Sometimes they wore exhausted, helpless expressions; other times they angrily kicked at the air with their feet. But their anger was diffused throughout their own uncontrolled world, and they never truly noticed the culprit."

# game/script.rpy:517
translate english start_4c4a2e9c:

    # nvl clear
    # "在借助心灵的复眼观察世界时，我既感到无穷的麻木、无穷的疲劳，又感到无穷的轻松自在。她的吻将我化为一场狂奔的风，也将我变成微不足道的沙砾。她的爱想必是令我强壮，也令我无能。\n\n我一面抓着公主的肠子向上攀爬，一面将一切不必多说、毫无分量的东西向下抛扔，让它们从此被遗弃吧！"
    nvl clear
    "Perceiving the world through the mind’s inner eyes, I felt infinite numbness and exhaustion, yet also endless ease. Her kiss had turned me into a gale of wild running and at the same time into an insignificant grain of sand. Her love had made me both strong and powerless."
    nvl clear
    "Clutching the princess’s entrails, I climbed upward, discarding everything unnecessary and weightless, letting them be abandoned forever!"

# game/script.rpy:521
translate english start_e8dd00e5:

    # nvl clear
    # "随着时间流逝，眼前的人们逐渐呵欠连连、脚步沉重，越来越多的景象出现在紧闭的门后、偷情的马厩和无光的幽林之中。我的形姿也不再从容，与旅程开始相比，就像一个开蒙的幼儿变成了垂暮的老人，必须仰仗外力才能过活。\n\n我看见狂饮不醉的兽群，在漆黑的夜里唱着歌，我看见公主以无穷的耐心和宽容等待着我，温柔而专注地注视着我。"
    nvl clear
    "As time passed, the people before me began yawning and trudging along; more scenes appeared behind locked doors, in secretive stables, and dark glades. My own form was no longer steady — compared to the start of the journey, it was as if a newly awakened child had become a frail old man dependent on outside help."
    nvl clear
    "I saw beasts that drank endlessly without getting drunk, singing songs in the pitch-black night; I saw the princess waiting for me with infinite patience and compassion, her gaze gentle and focused on me."

# game/script.rpy:525
translate english start_03e3a626:

    # nvl clear
    # "终于我走近了她的心。\n\n这是一个温暖潮湿的区室，我曾经剖开过一些女人，了解身体内部的构造，但她的身体并不全然相同。"
    nvl clear
    "Finally I drew close to her heart.\n\nIt was a warm, moist chamber. I had once dissected several women to understand the body’s inner structure, but her anatomy was not exactly the same."

# game/script.rpy:529
translate english start_929865f4:

    # "在浓郁几近滴水的墨色夜空，美艳照人的双头公主同我分享了高空的角落。她像一座肉身的宫殿，柔美地承接着我。"
    nvl clear
    "In the dense, almost dripping black of the night sky, the beautiful two-headed princess shared a corner of the high air with me. She was like a living palace, tenderly embracing me."

# game/script.rpy:531
translate english start_6ce3341d:

    # nvl clear
    # "还有那些熟睡的、发出鼾声的人类们，都浑然不觉地进入了我们所分享的时刻，又将在下一个黎明全身而退，仿佛从未离开过私密的梦境，从未被任何卑鄙的月光照见。在她的口腔之中，我看见嵌入牙床的长剑；在她的唇舌之中，我看见恨不得一口喝干的甜津。"
    nvl clear
    "And those humans sleeping and snoring were all unwittingly part of the moment we shared, and at dawn they would emerge completely whole, as if they had never left their private dreams or been touched by any vile moonlight. In her mouth I saw a sword embedded in the gums; on her lips and tongue I saw the sweet nectar I longed to drink dry in one gulp."

# game/script.rpy:535
translate english start_0000fbd8:

    # "{color=#649BDA}公主！{/color}我在心中喊道。{color=#649BDA}公主！公主！{/color}"
    nvl clear
    "{color=#649BDA}Princess!{/color} \n\nI shouted in my heart. \n\n{color=#649BDA}Princess! \n\nPrincess!{/color}"

# game/script.rpy:537
translate english start_02c6b226:

    # nvl clear
    # "……她就这样转过头来，露出另一颗\n头颅，露出我曾在上一次夜晚抛弃的人的面庞，这时我猛然想起：向我赐予了的吻的不是这张美丽的面庞——\n\n而是西尔维奥那又老又丑、令人作呕、眉头紧皱的脸啊！"
    nvl clear
    "…and she turned her head, revealing the other head — the face of the person I had abandoned last night. Then I suddenly remembered: the one who gave me the kiss was not that beautiful face —\n\nbut Silvio’s very old, ugly, revolting face, his brow furrowed in a scowl!"

# game/script.rpy:541
translate english start_76b2fe88_17:

    # nvl clear
    nvl clear

# game/script.rpy:544
translate english start_84d20913:

    # "如同金属在空气中碰撞，发出尖锐响亮的哀鸣。西尔维奥被成倍放大、因此更显露出层层瑕疵的死人面颊，正垂着他肮脏、衰老的睫毛。毛发又短又硬，从远处看来恐怕接近没有。\n\n他就像昨夜一样，保持着死去的姿态，目光没有看向我，也没有看向头颅面对的陆地——他的目光早已失去焦点。"
    "It was like metal colliding in the air, emitting a sharp, loud wail. \n\nSilvio’s dead cheeks, greatly magnified and thus revealing layers of blemishes, were drooping with his dirty, aged eyelashes. \n\nHis hair was short and coarse, almost none at all from afar."
    nvl clear
    "He remained just as he had last night, frozen in death’s pose, his gaze looking at neither me nor the land beyond the heads — his eyes had long since lost focus."

# game/script.rpy:546
translate english start_c5aa1c5e:

    # nvl clear
    # "但在我厌恶地瑟缩，想要退回到攀升以前的世界时，从背后传来的微小漩涡，却导致我寸步难移，如同撞上了胶状透明的墙壁。于是，我吸了一下鼻子。就像在模仿我懦弱的动作一般，眼前也传来了吸鼻子的动静。难不成，西尔维奥终于掉了眼泪吗？可他的头颅丝毫没有发生改变，只因夜晚吹来的风而被动地摇晃。可我预感到一阵会将人吞吃入腹的潮湿——"
    nvl clear
    "But as I recoiled in disgust, wanting to retreat to the world before this ascent, a small vortex seemed to arise from behind, preventing me from moving, as if I had collided with a transparent gelatinous wall. I sniffed. And, as if mimicking my cowardly act, I heard another sniff — could it be that Silvio had finally shed a tear? "
    nvl clear
    "Yet his skull showed no change, only swaying passively in the night breeze. \n\nStill, I sensed a wave of moisture that could engulf a person —"

# game/script.rpy:550
translate english start_3c9ccc99:

    # nvl clear
    # "也许我是个比西尔维奥更好的预言者，一大滴浑浊的泪落在西尔维奥的脸颊，顺着他没能刮净毛发的颧骨下坠。"
    nvl clear
    "Perhaps I was an even better prophet than Silvio: a large, murky tear fell down Silvio’s cheek, tracking beneath his unshaven cheekbone."

# game/script.rpy:554
translate english start_95977b82:

    # "当我想要抬头，看清这滴更高处的眼泪究竟来自怎样一张面庞时，居民们都深深地睡着了，双头公主也不再瞧我。"
    "As I wanted to look up and see whose face that tear came from, the townsfolk were all fast asleep, and the two-headed princess no longer looked at me."

# game/script.rpy:556
translate english start_76b2fe88_18:

    # nvl clear
    nvl clear

# game/script.rpy:559
translate english start_91b67aaf:

    # "而在发出一声微弱的叹息之后，"
    "And after emitting a faint sigh,"

# game/script.rpy:561
translate english start_cd27196f:

    # "这滴泪成了我的房屋。"
    "this tear became my house."

# game/script.rpy:563
translate english start_76b2fe88_19:

    # nvl clear
    nvl clear
