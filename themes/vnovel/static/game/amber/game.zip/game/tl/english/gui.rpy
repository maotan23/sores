
translate english python:

    gui.text_font = "IMFellDWPica.ttf"

    gui.interface_text_font = "ChangBanDianSong-16-SC.ttf"

    gui.text_size = 11
