﻿# TODO: Translation updated at 2026-01-17 01:41

translate english strings:

    # game/options.rpy:14
    old "Amber"
    new "Amber"

    # game/options.rpy:30
    old "剧本/程序：蔓\n\n情感支持：煤炭咪\n\n背景图片：https://texturelabs.org/\n\n图标：https://game-icons.net/\n\n音效：https://freesound.org/\n\n作曲：Kevin MacLeod (incompetech.com)\n\n\"That Zen Moment\"\n\n\"The Pyre\"\n\n\"Mystery Bazaar\"\n\n\"Exotics\"\n\n\"Blue Feather\"\n\n\"Heart of Nowhere\"\n\n\"Giant Wyrm\"\n\n\"The House of Leaves\"\n\n\"Night of Chaos\"\n\nCreative Commons: By Attribution 4.0 License (http://creativecommons.org/licenses/by/4.0)\n\n正文字体：人偶仿宋 16\n\n界面字体：长坂点宋 16 SC\n\nCopyright (c) 1990–2015 Font Silo / Keitarou Hiraki；2025 yzdnn（https://github.com/yzdnn）"
    new ""

