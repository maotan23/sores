﻿# TODO: Translation updated at 2026-01-17 01:41

translate english strings:

    # game/screens.rpy:294
    old "保存"
    new "Save"

    # game/screens.rpy:295
    old "读取"
    new "Load"

    # game/screens.rpy:296
    old "设置"
    new "Option"

    # game/screens.rpy:297
    old "自动"
    new "Auto"

    # game/screens.rpy:298
    old "跳过"
    new "Skip"

    # game/screens.rpy:340
    old "开始"
    new "Start"

    # game/screens.rpy:348
    old "继续"
    new "Continue"

    # game/screens.rpy:354
    old "结束回放"
    new "Stop"

    # game/screens.rpy:358
    old "标题"
    new "Title"

    # game/screens.rpy:503
    old "返回"
    new "Back"

    # game/screens.rpy:579
    old "关于"
    new "About"

    # game/screens.rpy:586
    old "版本 [config.version!t]\n"
    new "Version [config.version!t]\n"

    # game/screens.rpy:592
    old "引擎：{a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only]\n\n[renpy.license!t]"
    new ""

    # game/screens.rpy:622
    old "读取游戏"
    new "Load Game"

    # game/screens.rpy:627
    old "第 {} 页"
    new "Page {} "

    # game/screens.rpy:627
    old "自动存档"
    new "Quick Save"

    # game/screens.rpy:627
    old "快速存档"
    new "Quick Load"

    # game/screens.rpy:668
    old "{#file_time}%Y-%m-%d %H:%M"
    new "{#file_time}%Y-%m-%d %H:%M"

    # game/screens.rpy:668
    old "空存档位"
    new "Empty Story"

    # game/screens.rpy:688
    old "<"
    new "<"

    # game/screens.rpy:692
    old "{#auto_page}A"
    new "{#auto_page}A"

    # game/screens.rpy:695
    old "{#quick_page}Q"
    new "{#quick_page}Q"

    # game/screens.rpy:701
    old ">"
    new ">"

    # game/screens.rpy:706
    old "上传同步"
    new "Upload"

    # game/screens.rpy:710
    old "下载同步"
    new "Dowmload"

    # game/screens.rpy:769
    old "显示"
    new "Show"

    # game/screens.rpy:770
    old "窗口"
    new "window"

    # game/screens.rpy:771
    old "全屏"
    new "full"

    # game/screens.rpy:775
    old "快进"
    new "skip"

    # game/screens.rpy:776
    old "未读文本"
    new "unread"

    # game/screens.rpy:777
    old "选项后继续"
    new ""

    # game/screens.rpy:778
    old "忽略转场"
    new ""

    # game/screens.rpy:791
    old "文字速度"
    new "speed"

    # game/screens.rpy:795
    old "自动前进时间"
    new "auto time"

    # game/screens.rpy:802
    old "音乐音量"
    new "music volume"

    # game/screens.rpy:809
    old "音效音量"
    new "sound volume"

    # game/screens.rpy:815
    old "测试"
    new "test"

    # game/screens.rpy:819
    old "语音音量"
    new "click volume"

    # game/screens.rpy:830
    old "全部静音"
    new "mute all"

    # game/screens.rpy:920
    old "历史"
    new "history"

    # game/screens.rpy:948
    old "尚无对话历史记录。"
    new ""

    # game/screens.rpy:1006
    old "帮助"
    new "help"

    # game/screens.rpy:1015
    old "键盘"
    new "keyboard"

    # game/screens.rpy:1016
    old "鼠标"
    new "mouse"

    # game/screens.rpy:1019
    old "手柄"
    new ""

    # game/screens.rpy:1032
    old "回车"
    new "enter"

    # game/screens.rpy:1033
    old "推进对话并激活界面。"
    new ""

    # game/screens.rpy:1036
    old "空格"
    new "space"

    # game/screens.rpy:1037
    old "在没有选择的情况下推进对话。"
    new ""

    # game/screens.rpy:1040
    old "方向键"
    new ""

    # game/screens.rpy:1041
    old "导航界面。"
    new ""

    # game/screens.rpy:1044
    old "Esc"
    new "Esc"

    # game/screens.rpy:1045
    old "访问游戏菜单。"
    new ""

    # game/screens.rpy:1049
    old "按住时快进对话。"
    new ""

    # game/screens.rpy:1052
    old "Tab"
    new "Tab"

    # game/screens.rpy:1053
    old "切换对话快进。"
    new ""

    # game/screens.rpy:1056
    old "上一页"
    new ""

    # game/screens.rpy:1057
    old "回退至先前的对话。"
    new ""

    # game/screens.rpy:1060
    old "下一页"
    new ""

    # game/screens.rpy:1061
    old "向前至后来的对话。"
    new ""

    # game/screens.rpy:1065
    old "隐藏用户界面。"
    new ""

    # game/screens.rpy:1069
    old "截图。"
    new ""

    # game/screens.rpy:1073
    old "切换辅助{a=https://doc.renpy.cn/zh-CN/self_voicing.html}机器朗读{/a}。"
    new ""

    # game/screens.rpy:1077
    old "打开无障碍菜单。"
    new ""

    # game/screens.rpy:1083
    old "左键点击"
    new ""

    # game/screens.rpy:1087
    old "中键点击"
    new ""

    # game/screens.rpy:1091
    old "右键点击"
    new ""

    # game/screens.rpy:1095
    old "鼠标滚轮上"
    new ""

    # game/screens.rpy:1099
    old "鼠标滚轮下"
    new ""

    # game/screens.rpy:1106
    old "右扳机键\nA/底键"
    new ""

    # game/screens.rpy:1110
    old "左扳机键\n左肩键"
    new ""

    # game/screens.rpy:1114
    old "右肩键"
    new ""

    # game/screens.rpy:1118
    old "十字键，摇杆"
    new ""

    # game/screens.rpy:1122
    old "开始，向导，B/右键"
    new ""

    # game/screens.rpy:1126
    old "Y/顶键"
    new ""

    # game/screens.rpy:1129
    old "校准"
    new ""

    # game/screens.rpy:1193
    old "确定"
    new ""

    # game/screens.rpy:1194
    old "取消"
    new ""

    # game/screens.rpy:1239
    old "正在快进"
    new ""

    # game/screens.rpy:1547
    old "回退"
    new ""

    # game/screens.rpy:1550
    old "菜单"
    new "Menu"

